<?php
// Enqueue styles
function mytheme_enqueue_styles() {
    wp_enqueue_style('main-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'mytheme_enqueue_styles');

// Register menu
function mytheme_setup() {
    register_nav_menus([
        'main-menu' => __('Main Menu', 'my-custom-theme')
    ]);
}
add_action('after_setup_theme', 'mytheme_setup');

// //optional
// function mytheme_widgets_init() {
//     register_sidebar([
//         'name' => 'Main Sidebar',
//         'id' => 'main-sidebar',
//         'before_widget' => '<div class="widget">',
//         'after_widget' => '</div>',
//         'before_title' => '<h3>',
//         'after_title' => '</h3>',
//     ]);
// }
// add_action('widgets_init', 'mytheme_widgets_init');

