<?php get_header(); ?>

<main>
    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <article>
            <h1><?php the_title(); ?></h1>
            <p>Posted on <?php the_time('F j, Y'); ?> by <?php the_author(); ?></p>
            <div><?php the_content(); ?></div>

            <div class="post-meta">
                <p>Categories: <?php the_category(', '); ?></p>
                <p><?php the_tags('Tags: ', ', '); ?></p>
            </div>

            <?php comments_template(); ?>
        </article>
    <?php endwhile; endif; ?>
</main>

<?php get_footer(); ?>
