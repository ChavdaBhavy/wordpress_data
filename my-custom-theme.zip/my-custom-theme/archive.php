<?php get_header(); ?>

<main>
    <h1>
        <?php
        if ( is_category() ) {
        single_cat_title();
        } elseif ( is_tag() ) {
        single_tag_title();
        } elseif ( is_author() ) {
        echo 'Author: ' . get_the_author();
        } elseif ( is_day() ) {
        echo 'Archive: ' . get_the_date();
        } elseif ( is_month() ) {
        echo 'Archive: ' . get_the_date('F Y');
        } elseif ( is_year() ) {
        echo 'Archive: ' . get_the_date('Y');
        } else {
        echo 'Archives';
        }
        ?>
    </h1>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
        <article>
        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
        <p>Posted on <?php the_time('F j, Y'); ?> by <?php the_author(); ?></p>
        <div><?php the_excerpt(); ?></div>
        </article>
    <?php endwhile; else : ?>
        <p>No posts found.</p>
    <?php endif; ?>
</main>

<?php get_footer(); ?>
