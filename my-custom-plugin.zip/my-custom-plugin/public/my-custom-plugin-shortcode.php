<?php
// Shortcode function
function mcp_display_message_shortcode( $atts ) {
    // Optional attributes with default values
    $atts = shortcode_atts( array(
        'text' => 'Hello from My Custom Plugin!',
    ), $atts );

    // Return the HTML content
    return '<div class="mcp-message">' . esc_html( $atts['text'] ) . '</div>';
}

// Register the shortcode
add_shortcode( 'my_custom_plugin', 'mcp_display_message_shortcode' );

