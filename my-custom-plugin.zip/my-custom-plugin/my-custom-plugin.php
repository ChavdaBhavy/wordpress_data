<?php
/**
 * Plugin Name: My Custom Plugin
 * Plugin URI: https://example.com/
 * Description: A simple custom plugin example.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://your-site.com/
 * License: GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

function mcp_enqueue_assets() {
    wp_enqueue_style( 'mcp-style', plugin_dir_url( __FILE__ ) . 'assets/css/style.css' );
    wp_enqueue_script( 'mcp-script', plugin_dir_url( __FILE__ ) . 'assets/js/script.js', array('jquery'), null, true );
}
add_action( 'wp_enqueue_scripts', 'mcp_enqueue_assets' );

require_once plugin_dir_path(__FILE__) . 'public/my-custom-plugin-shortcode.php';   